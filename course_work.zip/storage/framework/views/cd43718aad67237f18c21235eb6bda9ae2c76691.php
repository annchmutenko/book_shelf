<?php $__env->startSection('header-title'); ?>
    <?php echo e(__("Edit genre")); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="py-12 max-w-7xl mx-auto sm:px-6 lg:px-8 admin-form">
        <form method="post" action="<?php echo e(route('admin.orders.update', $order)); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field('put'); ?>
            <div class="form-group">
                <div class="row">
                    <div class="col-12 col-md-6">
                        <label for="last-name">City</label>
                        <input type="text" class="form-control" value="<?php echo e($order->city); ?>" readonly>
                    </div>
                    <div class="col-12 col-md-6">
                        <label for="last-name">Post office</label>
                        <input type="text" class="form-control" value="<?php echo e($order->post_office); ?>" readonly>
                    </div>
                </div>
            </div>
            <div class="form-group">
                <div class="row">
                    <div class="col-12 col-lg-6">
                        <label for="last-name">User</label>
                        <input type="text" class="form-control" value="<?php echo e($order->user->name); ?>" readonly>
                    </div>
                </div>
            </div>
            <div class="form-group">
                <div class="row">
                    <div class="col-12 col-lg-6">
                        <label>Cost</label>
                        <input class="form-control" value="<?php echo e($order->books->sum('price')); ?>" readonly>
                    </div>
                </div>
            </div>
            <div class="form-group">
                <label>Status</label><br>
                <select class="form-control" name="status" id="exampleFormControlSelect1">
                    <option value="pending" <?php echo e($order->status == 'pending' ? 'selected' : ''); ?>>Pending</option>
                    <option value="processing" <?php echo e($order->status == 'processing' ? 'selected' : ''); ?>>Processing</option>
                    <option value="canceled" <?php echo e($order->status == 'canceled' ? 'selected' : ''); ?>>Canceled</option>
                    <option value="finished" <?php echo e($order->status == 'finished' ? 'selected' : ''); ?>>Finished</option>
                </select>
            </div>
            <button type="submit" class="btn btn-primary">Create</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('back.layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/book_store/resources/views/back/orders/edit.blade.php ENDPATH**/ ?>