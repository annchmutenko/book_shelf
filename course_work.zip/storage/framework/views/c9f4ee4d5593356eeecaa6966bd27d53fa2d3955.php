<?php $__env->startSection('content'); ?>
    <!-- catagory section -->
    <?php echo e($breadcrumbs); ?>

    <section class="catagory_section layout_padding">
        <div class="catagory_container">
            <div class="container ">
                <div class="heading_container heading_center">
                    <h2>
                        <?php echo e($genre->title); ?>

                    </h2>
                </div>
                <div class="row">
                    <?php if($books->count() == 0): ?>
                        <div class="container heading_container heading_center">
                            <h3>There is nothing here yet</h3>
                        </div>
                    <?php endif; ?>
                    <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-sm-6 col-md-4 ">
                            <div class="box ">
                                <a href="<?php echo e(route('front.books.show', $book->slug)); ?>">
                                    <div class="img-box">
                                        <img src="<?php echo e($book->iconUrl); ?>" alt="<?php echo e($book->title); ?>">
                                    </div>
                                    <div class="detail-box">
                                        <h5>
                                            <?php echo e($book->title); ?>

                                        </h5>
                                    </div>
                                </a>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.layout.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/book_store/resources/views/front/genres/show.blade.php ENDPATH**/ ?>