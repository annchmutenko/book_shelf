<?php $__env->startSection('content'); ?>
    <!-- catagory section -->
    <?php echo e($breadcrumbs); ?>

    <section class="catagory_section layout_padding">
        <div class="catagory_container">
            <div class="container ">
                <div class="heading_container heading_center">
                    <h2>
                        Books <?php if(request()->routeIs('front.categories')): ?> Categories <?php else: ?> Genres <?php endif; ?>
                    </h2>
                    <p>
                        There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration
                    </p>
                </div>
                <div class="row">
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-sm-6 col-md-4 catagory_section">
                            <div class="box ">
                                <a href="<?php echo e(route('front.categories.show', $category->id)); ?>">
                                    <div class="img-box">
                                        <img src="<?php echo e($category->iconUrl); ?>" alt="<?php echo e($category->title); ?>">
                                    </div>
                                    <div class="detail-box">
                                        <h5>
                                            <?php echo e($category->title); ?>

                                        </h5>
                                        <p>
                                            <?php echo e($category->description); ?>

                                        </p>
                                    </div>
                                </a>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </section>

    <!-- end catagory section -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.layout.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/book_store/resources/views/front/categories.blade.php ENDPATH**/ ?>