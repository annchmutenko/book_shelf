<?php $__env->startSection('header-title'); ?>
    <?php echo e(__("Edit book")); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="py-12 max-w-7xl mx-auto sm:px-6 lg:px-8 admin-form">
        <form method="post" action="<?php echo e(route('admin.books.update', $book)); ?>" enctype="multipart/form-data">
            <?php echo method_field('put'); ?>
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <div class="row">
                    <div class="col-12">
                        <label for="last-name">Title</label>
                        <input type="text" name="title" class="form-control" value="<?php echo e(old('title', $book->title)); ?>" required>
                    </div>
                </div>
            </div>
            <div class="form-group">
                <div class="row">
                    <div class="col-12">
                        <label for="last-name">Slug</label>
                        <input type="text" name="slug" class="form-control" value="<?php echo e(old('slug', $book->slug)); ?>" required>
                    </div>
                </div>
            </div>
            <div class="form-group">
                <div class="row">
                    <div class="col-12">
                        <label for="last-name">Description</label>
                        <textarea name="description" class="form-control" required><?php echo e(old('description', $book->description)); ?></textarea>
                    </div>
                </div>
            </div>
            <div class="form-group">
                <div class="row">
                    <div class="col-12">
                        <label>Author</label>
                        <input name="author" class="form-control" value="<?php echo e(old('author', $book->author)); ?>" required>
                    </div>
                </div>
            </div>
            <div class="form-group">
                <div class="row">
                    <div class="col-12">
                        <label>Pages</label>
                        <input name="pages" class="form-control" value="<?php echo e(old('pages', $book->pages)); ?>" required>
                    </div>
                </div>
            </div>
            <div class="form-group">
                <div class="row">
                    <div class="col-12">
                        <label>Cover</label>
                        <input name="cover" class="form-control" value="<?php echo e(old('cover', $book->cover)); ?>" required>
                    </div>
                </div>
            </div>
            <div class="form-group">
                <div class="row">
                    <div class="col-12">
                        <label>Publisher</label>
                        <input name="publisher" class="form-control" value="<?php echo e(old('publisher', $book->publisher)); ?>" required>
                    </div>
                </div>
            </div>
            <div class="form-group">
                <div class="row">
                    <div class="col-12">
                        <label>Language</label>
                        <input name="language" class="form-control" value="<?php echo e(old('language', $book->language)); ?>" required>
                    </div>
                </div>
            </div>
            <div class="form-group">
                <div class="row">
                    <div class="col-12">
                        <label>Price</label>
                        <input name="price" class="form-control" value="<?php echo e(old('price', $book->price)); ?>" required>
                    </div>
                </div>
            </div>
            <div class="form-group">
                <label>Genre</label><br>
                <select class="form-control" name="genre_id" id="exampleFormControlSelect1" required>
                    <?php $__currentLoopData = $genres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $genre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($genre->id); ?>" <?php echo e($book->genre_id == $genre->id ? 'selected' : ''); ?>><?php echo e($genre->title); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="form-group">
                <label>Categories</label><br>
                <select class="form-control" name="categories[]" multiple id="exampleFormControlSelect1" required>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($category->id); ?>" <?php echo e(in_array($category->id, $book->categories->pluck('id')->toArray()) ? 'selected' : ''); ?>><?php echo e($category->title); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="form-group">
                <div class="row">
                    <div class="col-12 col-lg-6">
                        <input type="file" name="icon" id="custom-file" class="custom-file-input">
                        <label class="ml-3 custom-file-label" for="custom-file">Upload icon</label>
                        <small>Current icon: <a href="<?php echo e($book->iconUrl); ?>"><?php echo e($book->iconUrl); ?></a></small>
                    </div>
                </div>
            </div>
            <button type="submit" class="btn btn-primary">Create</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('back.layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/book_store/resources/views/back/books/edit.blade.php ENDPATH**/ ?>