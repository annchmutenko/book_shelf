<?php $__env->startSection('header-title'); ?>
    <?php echo e(__("Welcome to admin panel")); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('back.layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/book_store/resources/views/back/home.blade.php ENDPATH**/ ?>