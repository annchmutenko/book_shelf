<?php $__env->startSection('header-title'); ?>
    <?php echo e(__("Create book")); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="py-12 max-w-7xl mx-auto sm:px-6 lg:px-8 admin-form">
        <form method="post" action="<?php echo e(route('admin.books.store')); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <div class="row">
                    <div class="col-12">
                        <label for="last-name">Title</label>
                        <input type="text" name="title" class="form-control" value="<?php echo e(old('title') ?? ''); ?>" required>
                    </div>
                </div>
            </div>
            <div class="form-group">
                <div class="row">
                    <div class="col-12">
                        <label for="last-name">Slug</label>
                        <input type="text" name="slug" class="form-control" value="<?php echo e(old('slug') ?? ''); ?>" required>
                    </div>
                </div>
            </div>
            <div class="form-group">
                <div class="row">
                    <div class="col-12">
                        <label for="last-name">Description</label>
                        <textarea name="description" class="form-control" required><?php echo e(old('description')); ?></textarea>
                    </div>
                </div>
            </div>
            <div class="form-group">
                <div class="row">
                    <div class="col-12">
                        <label>Author</label>
                        <input name="author" class="form-control" value="<?php echo e(old('author')); ?>" required>
                    </div>
                </div>
            </div>
            <div class="form-group">
                <div class="row">
                    <div class="col-12">
                        <label>Pages</label>
                        <input name="pages" class="form-control" value="<?php echo e(old('pages')); ?>" required>
                    </div>
                </div>
            </div>
            <div class="form-group">
                <div class="row">
                    <div class="col-12">
                        <label>Cover</label>
                        <input name="cover" class="form-control" value="<?php echo e(old('cover')); ?>" required>
                    </div>
                </div>
            </div>
            <div class="form-group">
                <div class="row">
                    <div class="col-12">
                        <label>Publisher</label>
                        <input name="publisher" class="form-control" value="<?php echo e(old('publisher')); ?>" required>
                    </div>
                </div>
            </div>
            <div class="form-group">
                <div class="row">
                    <div class="col-12">
                        <label>Language</label>
                        <input name="language" class="form-control" value="<?php echo e(old('language')); ?>" required>
                    </div>
                </div>
            </div>
            <div class="form-group">
                <div class="row">
                    <div class="col-12">
                        <label>Price</label>
                        <input name="price" class="form-control" value="<?php echo e(old('price')); ?>" required>
                    </div>
                </div>
            </div>
            <div class="form-group">
                <label>Genre</label><br>
                <select class="form-control" name="genre_id" id="exampleFormControlSelect1" required>
                    <?php $__currentLoopData = $genres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $genre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($genre->id); ?>"><?php echo e($genre->title); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="form-group">
                <label>Categories</label><br>
                <select class="form-control" name="categories[]" multiple id="exampleFormControlSelect1" required>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($category->id); ?>"><?php echo e($category->title); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="form-group">
                <div class="row">
                    <div class="col-12 col-lg-6">
                        <input type="file" name="icon" id="custom-file" class="custom-file-input">
                        <label class="ml-3 custom-file-label" for="custom-file">Upload icon</label>
                    </div>
                </div>
            </div>
            <button type="submit" class="btn btn-primary">Create</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('back.layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/book_store/resources/views/back/books/create.blade.php ENDPATH**/ ?>