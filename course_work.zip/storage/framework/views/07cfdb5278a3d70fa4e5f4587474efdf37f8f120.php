<?php $__env->startSection('header-title'); ?>
    <?php echo e(__("Edit category")); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="py-12 max-w-7xl mx-auto sm:px-6 lg:px-8 admin-form">
        <form method="post" action="<?php echo e(route('admin.categories.update', $category)); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field('put'); ?>
            <div class="form-group">
                <div class="row">
                    <div class="col-12 col-lg-6">
                        <label for="last-name">Title</label>
                        <input type="text" name="title" class="form-control" value="<?php echo e($category->title); ?>" required>
                    </div>
                </div>
            </div>
            <div class="form-group">
                <div class="row">
                    <div class="col-12 col-lg-6">
                        <label>Description</label>
                        <textarea name="description" class="form-control"><?php echo e($category->description); ?></textarea>
                    </div>
                </div>
            </div>
            <div class="form-group">
                <div class="row">
                    <div class="col-12 col-lg-6">
                        <input type="file" name="icon" id="custom-file" class="custom-file-input">
                        <label class="ml-3 custom-file-label" for="custom-file">Upload icon</label>
                        <?php if(isset($category->icon)): ?>
                            <small>Current icon: <a href="<?php echo e($category->iconUrl); ?>"><?php echo e($category->iconUrl); ?></a></small>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <button type="submit" class="btn btn-primary">Update</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('back.layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/book_store/resources/views/back/categories/edit.blade.php ENDPATH**/ ?>