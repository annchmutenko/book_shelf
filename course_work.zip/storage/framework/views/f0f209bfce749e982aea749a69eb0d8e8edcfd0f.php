<?php $__env->startSection('content'); ?>
    <?php echo e($breadcrumbs); ?>

    <!-- catagory section -->
    <section class="catagory_section layout_padding">
        <div class="book_container">
            <div class="container ">
                <div class="heading_container heading_center">
                    <h2>
                        <?php echo e($book->title); ?>

                    </h2>
                </div>
                <div class="row">
                    <div class="col-12 col-md-3">
                        <img class="h-100 w-100" src="<?php echo e($book->iconUrl); ?>">
                    </div>
                    <div class="col-12 col-md-9">
                        <p>Author: <?php echo e($book->author); ?></p>
                        <p>Pages: <?php echo e($book->pages); ?></p>
                        <p>Language: <?php echo e($book->language); ?></p>
                        <p>Genre: <a href="<?php echo e(route('front.genres.show', $book->genre_id)); ?>"><?php echo e($book->genre->title); ?></a></p>
                        <p>Categories: <?php echo empty($book->categoriesToString) ? 'None' : $book->categoriesToString; ?></p>
                        <p>Cover: <?php echo e($book->cover); ?></p>
                    </div>
                </div>
                <?php if(auth()->check()): ?>
                    <div class="buy mt-2">
                        <div class="row">
                            <div class="col-6">
                                <div class="row">
                                    <div class="col-12">
                                        <span class="font-weight-bold" aria-describedby="availability"><?php echo e($book->price); ?> UAH</span>
                                        <small class="<?php echo e($book->is_available ? 'text-success' : 'text-danger'); ?>" id="availability"><?php echo e($book->is_available ? 'Available' : 'Not available'); ?></small>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-12">
                                        <cart :book-props="<?php echo e($book); ?>" :user-props="<?php echo e(auth()->user()); ?>" inline-template>
                                            <button class="btn btn-success" @click.prevent="addToCart">Buy</button>
                                        </cart>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                <?php endif; ?>
                    <div class="description-block mt-2">
                        <div class="row">
                            <div class="col-12">
                                <h3>About the book</h3>
                            </div>
                            <div class="col-12">
                                <?php echo e($book->description); ?>

                            </div>

                        </div>
                    </div>
                    <div class="similar-block mt-2">
                        <div class="row">
                            <div class="col-12">
                                <h3>Similar books</h3>
                            </div>
                            <div class="col-12">
                                <?php if($similarBooks->count() == 0): ?>
                                    <p>There is nothing here yet</p>
                                <?php endif; ?>
                                <?php $__currentLoopData = $similarBooks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $similarBook): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-sm-6 col-md-4 ">
                                        <div class="box ">
                                            <a href="<?php echo e(route('front.books.show', $similarBook->slug)); ?>">
                                                <div class="img-box">
                                                    <img src="<?php echo e($similarBook->iconUrl); ?>" alt="<?php echo e($similarBook->title); ?>">
                                                </div>
                                                <div class="detail-box">
                                                    <h5>
                                                        <?php echo e($similarBook->title); ?>

                                                    </h5>
                                                </div>
                                            </a>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>

                        </div>
                    </div>
            </div>
        </div>
    </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.layout.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/book_store/resources/views/front/books/show.blade.php ENDPATH**/ ?>