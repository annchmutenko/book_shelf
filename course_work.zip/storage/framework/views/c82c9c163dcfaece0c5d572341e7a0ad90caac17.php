<?php $__env->startSection('content'); ?>
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav">
                <li class="nav-item">
                    <a class="nav-link <?php echo e(request()->routeIs('front.profile.settings') ? 'active' : ''); ?>" href="<?php echo e(route('front.profile.settings')); ?>">Settings </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('front.profile.orders')); ?>">Orders </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('front.profile.cart')); ?>">Cart </a>
                </li>
                <li class="nav-item">
                    <form action="<?php echo e(route('logout')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <button class="btn nav-link" href="#">Logout </button>
                    </form>
                </li>
            </ul>
        </div>
    </nav>

    <section class="about_section layout_padding">
        <div class="container ">
            <div class="row">
                <div class="col-md-12">
                    <div class="detail-box">
                        <div class="heading_container">
                            <h2>
                                Make order
                            </h2>
                        </div>
                        <?php if($errors->any()): ?>
                            <div class="alert alert-danger">
                                <ul>
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        <?php endif; ?>
                        <?php if(session()->has('error')): ?>
                            <div class="alert alert-danger">
                                <ul>
                                    <li><?php echo e(session('error')); ?></li>
                                </ul>
                            </div>
                        <?php endif; ?>
                        <?php if(session()->has('success')): ?>
                            <div class="alert alert-success">
                                <ul>
                                    <li><?php echo e(session('success')); ?></li>
                                </ul>
                            </div>
                        <?php endif; ?>
                        <form action="<?php echo e(route('front.profile.create-order')); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <label for="city">City</label>
                                <input type="text" id="city" name="city" class="form-control" required placeholder="City">
                            </div>
                            <div class="form-group">
                                <label for="exampleInputEmail1">Post office</label>
                                <input type="text" name="post_office" class="form-control" required placeholder="Post office">
                            </div>
                            <div class="row">
                                <div class="col-12">
                                    <h5>Books</h5>
                                    <?php $__currentLoopData = $cart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="card mb-3">
                                            <div class="card-body">
                                                <div class="d-flex justify-content-between">
                                                    <div class="d-flex flex-row align-items-center">
                                                        <div>
                                                            <img src="<?php echo e($item->book->iconUrl); ?>"
                                                                class="img-fluid rounded-3" alt="Shopping item" style="width: 65px;">
                                                        </div>
                                                        <div class="ml-3">
                                                            <h5><?php echo e($item->book->title); ?></h5>
                                                            <p class="small mb-0"><?php echo e($item->book->author); ?>, <?php echo e($item->book->pages); ?> pages</p>
                                                        </div>
                                                    </div>
                                                    <div class="d-flex flex-row align-items-center">
                                                        <div style="width: 90px;">
                                                            <h5 class="mb-0"><?php echo e($item->book->price); ?> UAH</h5>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                            <button type="submit" class="btn btn-primary">Submit</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.layout.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/book_store/resources/views/front/profile/make_order.blade.php ENDPATH**/ ?>