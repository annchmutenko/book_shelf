<?php $__env->startSection('content'); ?>
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav">
                <li class="nav-item">
                    <a class="nav-link <?php echo e(request()->routeIs('front.profile.settings') ? 'active' : ''); ?>" href="<?php echo e(route('front.profile.settings')); ?>">Settings </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('front.profile.orders')); ?>">Orders </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('front.profile.cart')); ?>">Cart </a>
                </li>
                <li class="nav-item">
                    <form action="<?php echo e(route('logout')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <button class="btn nav-link" href="#">Logout </button>
                    </form>
                </li>
            </ul>
        </div>
    </nav>

    <section class="about_section layout_padding">
        <div class="container ">
            <div class="row">
                <div class="col-md-12">
                    <div class="detail-box">
                        <div class="heading_container">
                            <h2>
                                Settings
                            </h2>
                        </div>
                        <?php if($errors->any()): ?>
                            <div class="alert alert-danger">
                                <ul>
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        <?php endif; ?>
                        <?php if(session()->has('error')): ?>
                            <div class="alert alert-danger">
                                <ul>
                                    <li><?php echo e(session('error')); ?></li>
                                </ul>
                            </div>
                        <?php endif; ?>
                        <?php if(session()->has('success')): ?>
                            <div class="alert alert-success">
                                <ul>
                                    <li><?php echo e(session('success')); ?></li>
                                </ul>
                            </div>
                        <?php endif; ?>
                        <form action="<?php echo e(route('front.profile.update')); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('put'); ?>
                            <div class="form-group">
                                <label for="exampleInputEmail1">Name</label>
                                <input type="text" name="name" value="<?php echo e($user->name ?? ''); ?>" class="form-control" placeholder="Name">
                            </div>
                            <div class="form-group">
                                <label for="exampleInputEmail1">Email address</label>
                                <input type="email" name="email" class="form-control" value="<?php echo e($user->email ?? ''); ?>" placeholder="Enter email">
                            </div>
                            <div class="form-group">
                                <label for="exampleInputPassword1">Your current password</label>
                                <input type="password" name="current_password" class="form-control" placeholder="Current password">
                            </div>
                            <div class="form-group">
                                <label for="exampleInputPassword1">New password</label>
                                <input type="password" name="new_password" class="form-control" placeholder="New password">
                            </div>
                            <div class="form-group">
                                <label for="exampleInputPassword1">Confirm password</label>
                                <input type="password" name="new_password_confirmation" class="form-control" placeholder="Confirm password">
                            </div>
                            <button type="submit" class="btn btn-primary">Submit</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.layout.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/book_store/resources/views/front/profile/index.blade.php ENDPATH**/ ?>