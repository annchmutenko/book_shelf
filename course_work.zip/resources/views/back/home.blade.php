@extends('back.layouts.admin')

@section('header-title')
    {{ __("Welcome to admin panel") }}
@endsection
